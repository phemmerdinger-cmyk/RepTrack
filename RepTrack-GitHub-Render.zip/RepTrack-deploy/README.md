# RepTrack deployment

1. Upload `index.html`, `server.js`, and `package.json` to the top level of a GitHub repository.
2. In Render create a **Web Service** (not Static Site), connect the repo, choose Node, use Build Command `npm install` and Start Command `npm start`.
3. Deploy and copy the assigned `https://YOUR-SITE.onrender.com` URL.
4. Visit https://developer.whoop.com/ and register an app. Use redirect URI `https://YOUR-SITE.onrender.com/api/whoop/callback` and request `read:recovery`, `read:sleep`, `read:cycles`, and `offline` (if available).
5. On Render -> your Web Service -> Environment, add WHOOP_CLIENT_ID, WHOOP_CLIENT_SECRET, PUBLIC_URL (site base URL, no ending slash), and SESSION_SECRET (a random secret string at least 32 characters long).
6. Save environment and redeploy. Open your site -> WHOOP -> Connect WHOOP.

**Privacy and caveats**

- Never commit client secrets to GitHub or paste them into HTML.
- Workout logs are stored in browser localStorage and **do not automatically sync between devices**. Export/import backups to transfer logs.
- WHOOP tokens are stored in encrypted, HttpOnly browser cookies. Changing SESSION_SECRET signs everyone out. Clearing cookies disconnects WHOOP.
- This project is designed for personal use and has not been independently security-audited. For a public multiuser service, add persistent accounts, more comprehensive security controls, and a database.
- Free Render Web Services may spin down when idle; initial requests can take longer.
- Only tested for server startup and static HTML in this environment. WHOOP live authentication requires your own WHOOP app and credentials and has not been tested here.
